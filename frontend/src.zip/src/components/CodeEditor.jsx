import { useState, useEffect } from 'react';
import Editor from '@monaco-editor/react';
import { useLeetcodeData } from '@/hooks/useLeetcodeData';

export function CodeEditor({ problem, onBack }) {
  const slug = problem?.leetcode_slug;
  const title = problem?.title;

  const [language, setLanguage] = useState('python3');
  const [code, setCode] = useState('');

  const { data, loading, error, starterCode, testCases } = useLeetcodeData(title, slug, language);
  console.log("CodeEditor data:", data,"loading:", loading, "error:", error, "starterCode:", starterCode, "testCases:", testCases);
  
  useEffect(() => {
    if (starterCode) {
      setCode(starterCode);
    }
  }, [starterCode]);

  if (loading) return <div>Loading...</div>;
  if (error) return <div>{error}</div>;
  if (!data) return null;

  return (
    <div className="ide-layout">

      {/* LEFT SIDE - DESCRIPTION */}
      <div
        className="description"
        dangerouslySetInnerHTML={{ __html: data.contentHtml }}  // ✅ was data.description_html
      />

      {/* RIGHT SIDE - EDITOR */}
      <div className="editor-panel">

        <select
          value={language}
          onChange={(e) => setLanguage(e.target.value)}
        >
          {data.codeSnippets?.map((s) => (   // ✅ was data.code_snippets
            <option key={s.langSlug} value={s.langSlug}>
              {s.langSlug}
            </option>
          ))}
        </select>

        <Editor
          height="500px"
          theme="vs-dark"
          language={mapLanguage(language)}
          value={code}
          onChange={(val) => setCode(val)}
          options={{
            fontSize: 14,
            minimap: { enabled: false },
            automaticLayout: true,
            wordWrap: 'on',
          }}
        />

        {/* Testcases */}
        <div className="testcase-panel">
          {testCases.map((tc, i) => (   // ✅ tc is { inputStr, expected, explanation }
            <div key={i} className="testcase">
              <pre><strong>Input:</strong> {tc.inputStr}</pre>
              <pre><strong>Expected:</strong> {String(tc.expected)}</pre>
              {tc.explanation && <p><strong>Explanation:</strong> {tc.explanation}</p>}
            </div>
          ))}
        </div>

      </div>
    </div>
  );
}

function mapLanguage(lang) {
  const map = {
    python3: 'python',
    python: 'python',
    javascript: 'javascript',
    typescript: 'typescript',
    cpp: 'cpp',
    java: 'java',
  };
  return map[lang] || 'plaintext';
}